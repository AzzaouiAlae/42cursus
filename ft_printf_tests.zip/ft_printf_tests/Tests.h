#ifndef TESTS_H
# define TESTS_H

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdint.h>
#include "../ft_printf_/ft_printf.h"
# include "Unity-master/src/unity.h"
#include "ft_printf_to_str.c"
#include "Hex_Tests.c"
#include "simple_Tests.c"
#include "Str_Tests.c"
#include "Char_Tests.c"
#include "nums_Tests.c"
#include "mix_test.c"
#include "Percent_tests.c"

void setUp(void)
{
  redirect_print_to_file();
}

void tearDown(void)
{
    free(buffer);
    if(buffer2)
      free(buffer2);
    buffer2 = NULL;
}

#endif