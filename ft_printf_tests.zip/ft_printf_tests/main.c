#include "Tests.h"

int	main(void)
{
    simple_Tests();
    Char_Tests();
    nums_Tests();
    Str_Tests();
    mix_Tests();
    Hex_Tests();
    Percent_tests();
    return (UnityEnd());
}